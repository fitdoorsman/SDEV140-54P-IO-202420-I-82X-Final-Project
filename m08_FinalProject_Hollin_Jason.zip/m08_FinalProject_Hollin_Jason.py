# Expense Tracker
# Date: 2024-11-24
# Author: Jason Hollin
# IDE: Visual Studio Code

# This program allows users to track their expenses, set monthly income, define budgets for various categories,
# and compare their expenses with their budgets using a graphical summary.

# Pseudocode:
# START PROGRAM
# 1. INITIALIZE MAIN APPLICATION
#    - Set up main application window with title, size, and background.
#    - Define data storage:
#       - expenses = [] (list of tuples to store amount and category)
#       - budgets = {} (dictionary for storing category budgets)
#       - monthly_income = 0 (variable to hold monthly income)
# 2. DISPLAY MAIN MENU
#    - Add buttons for:
#        a) Set Monthly Income
#        b) Set Budgets
#        c) Add Expense
#        d) View Summary
#        e) Exit Program
# 3. DEFINE FUNCTION: show_set_income_window
#    - Purpose: Allow user to input and save their monthly income.
#       DISPLAY input field to prompt user: "Enter Monthly Income ($):"
#       IF user input is a valid positive number:
#           STORE input into monthly_income
#           DISPLAY success message ("Monthly income set to $X.")
#       ELSE:
#           DISPLAY error message ("Invalid input. Enter a valid number.")
# 4. DEFINE FUNCTION: show_set_budget_window
#    - Purpose: Allow user to set budgets for predefined categories.
#    Pseudocode:
#       DISPLAY input fields for each category:
#           FOR each predefined category:
#               PROMPT user to enter budget
#               STORE input in budgets dictionary
#               IF no input provided:
#                   DEFAULT budget to 0
#       DISPLAY success message ("Budgets updated successfully!")
# 5. DEFINE FUNCTION: show_add_expense_window
#    - Purpose: Allow user to enter an expense amount and select a category.
#       PROMPT user to input expense amount
#       PROMPT user to select a category from dropdown
#       IF expense amount is valid (positive number):
#           ADD (amount, category) to expenses list
#           CALCULATE total expenses for selected category
#           IF total category expenses > category budget:
#               DISPLAY warning ("Expenses in [Category] exceed the budget!")
#           CALCULATE total overall expenses
#           IF total overall expenses > monthly_income:
#               DISPLAY warning ("Total expenses exceed monthly income!")
#           DISPLAY success message ("Expense added successfully!")
#       ELSE:
#           DISPLAY error message ("Invalid expense amount. Please try again.")
# 6. DEFINE FUNCTION: show_summary_window
#    - Purpose: Display a graphical comparison of expenses versus budgets.
#       CALCULATE total expenses for each category:
#           FOR each expense in expenses list:
#               ADD expense amount to corresponding category total
#       PREPARE data for plotting:
#           - Budget values for each category
#           - Expense values for each category
#       PLOT bar chart:
#           - Categories on x-axis
#           - Budgets and Expenses as two separate bars
#           - Add legend for clarity
#           - Rotate x-axis labels for readability
#       DISPLAY the chart to the user.
# 7. DEFINE FUNCTION: exit_program
#    - Purpose: Exit the application.
#       CLOSE the main application window.
# 8. RUN MAIN PROGRAM
#    - INITIALIZE the main window.
#    - DISPLAY MAIN MENU with buttons for:
#        - Set Monthly Income
#        - Set Budgets
#        - Add Expense
#        - View Summary
#        - Exit Program
#    - BIND each button to its respective function:
#        - Set Monthly Income -> show_set_income_window()
#        - Set Budgets -> show_set_budget_window()
#        - Add Expense -> show_add_expense_window()
#        - View Summary -> show_summary_window()
#        - Exit -> exit_program()
#    - START main event loop.
# END PROGRAM

import os

import tkinter as tk

from tkinter import messagebox

from PIL import Image, ImageTk

import matplotlib.pyplot as plt



class ExpenseTrackerApp:

    def __init__(self, root):

        self.root = root

        self.root.title("Expense Tracker Budgeting Tool")

        self.root.geometry("500x700")

        

        # Data Storage

        self.budgets = {}

        self.expenses = {}

        self.monthly_income = 0  # Default value for monthly income

        

        # Load Images

        self.bg_photo_home = self.safe_load_image("image1.png", 500, 200)

        self.bg_photo_title = self.safe_load_image("image2.png", 500, 200)



        # X Button Behavior

        self.root.protocol("WM_DELETE_WINDOW", self.exit_program)

        

        # Show Home Screen

        self.create_home_screen()

    

    # Load Images Dynamically

    def safe_load_image(self, path, width, height):

        try:

            script_dir = os.path.dirname(os.path.abspath(__file__))  # Get current directory

            full_path = os.path.join(script_dir, path)

            image = Image.open(full_path).resize((width, height), Image.Resampling.LANCZOS)

            return ImageTk.PhotoImage(image)

        except Exception as e:

            print(f"Error loading image '{path}': {e}")

            return None



    # Clear Window

    def clear_window(self):

        for widget in self.root.winfo_children():

            widget.destroy()



    # Exit Program

    def exit_program(self):

        self.root.destroy()



    # Home Screen

    def create_home_screen(self):

        self.clear_window()

        self.root.protocol("WM_DELETE_WINDOW", self.exit_program)

        

        if self.bg_photo_home:

            tk.Label(self.root, image=self.bg_photo_home).pack(fill="x")

        tk.Label(self.root, text="Expense Tracker Budgeting Tool", font=("Arial", 18, "bold"), 

                 bg="#2E3B55", fg="white").pack(pady=10, fill="x")

        

        buttons = [

            ("Set Monthly Income", "blue", self.set_monthly_income),

            ("Set Budgets", "green", self.set_budgets_screen),

            ("Add Expense", "orange", self.add_expense_screen),

            ("View Summary", "purple", self.view_summary),

            ("Exit", "red", self.exit_program)

        ]

        

        for text, color, command in buttons:

            tk.Button(self.root, text=text, font=("Arial", 12, "bold"), bg=color, fg="white",

                      height=2, command=command).pack(fill="x", padx=50, pady=5)



    # Set Monthly Income

    def set_monthly_income(self):

        self.clear_window()

        self.root.protocol("WM_DELETE_WINDOW", self.create_home_screen)

        tk.Label(self.root, text="Set Monthly Income", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(self.root, text="Enter Monthly Income:", font=("Arial", 12)).pack(pady=5)

        

        self.income_entry = tk.Entry(self.root, width=30)

        self.income_entry.pack(pady=5)

        

        tk.Button(self.root, text="SAVE", font=("Arial", 12, "bold"), bg="green", fg="white",

                  command=self.save_income).pack(pady=20)



    def save_income(self):

        income = self.income_entry.get()

        if not income.isdigit() or int(income) <= 0:

            messagebox.showerror("Error", "Please enter a valid positive number for income.")

        else:

            self.monthly_income = int(income)

            messagebox.showinfo("Success", f"Monthly Income Saved: ${income}")

            self.create_home_screen()



    # Set Budgets

    def set_budgets_screen(self):

        self.clear_window()

        self.root.protocol("WM_DELETE_WINDOW", self.create_home_screen)

        

        tk.Label(self.root, text="Set Budgets", font=("Arial", 16, "bold")).pack(pady=10)

        self.budget_entries = {}

        

        categories = ["Groceries", "Dining Out", "Utilities", "Housing", "Transportation", 

                      "Insurance", "Health", "Cellphone", "Kids", "Pets", "Debt", "Lifestyle", 

                      "Personal", "Saving", "Other"]

        

        for category in categories:

            frame = tk.Frame(self.root)

            frame.pack(fill="x", padx=20, pady=5)

            tk.Label(frame, text=f"{category}:", font=("Arial", 12)).pack(side="left")

            entry = tk.Entry(frame, width=25)

            entry.pack(side="right")

            self.budget_entries[category] = entry

        

        tk.Button(self.root, text="SAVE", font=("Arial", 12, "bold"), bg="green", fg="white",

                  command=self.save_budgets).pack(pady=20)



    def save_budgets(self):

        for category, entry in self.budget_entries.items():

            value = entry.get()

            self.budgets[category] = int(value) if value.isdigit() else 0

        messagebox.showinfo("Success", "Budgets Saved!")

        self.create_home_screen()



    # Add Expense

    def add_expense_screen(self):

        self.clear_window()

        self.root.protocol("WM_DELETE_WINDOW", self.create_home_screen)

        

        tk.Label(self.root, text="Add Expenses", font=("Arial", 16, "bold")).pack(pady=10)

        self.expense_entries = {}

        

        for category in self.budgets.keys():

            frame = tk.Frame(self.root)

            frame.pack(fill="x", padx=20, pady=5)

            tk.Label(frame, text=f"{category}:", font=("Arial", 12)).pack(side="left")

            entry = tk.Entry(frame, width=25)

            entry.pack(side="right")

            self.expense_entries[category] = entry

        

        tk.Button(self.root, text="SAVE", font=("Arial", 12, "bold"), bg="orange", fg="white",

                  command=self.save_expenses).pack(pady=20)



    def save_expenses(self):

        for category, entry in self.expense_entries.items():

            value = entry.get()

            self.expenses[category] = int(value) if value.isdigit() else 0

        messagebox.showinfo("Success", "Expenses Saved!")

        self.create_home_screen()



    # View Summary

    def view_summary(self):

        total_expenses = sum(self.expenses.get(cat, 0) for cat in self.budgets.keys())

        remaining_balance = self.monthly_income - total_expenses

        

        # Generate Bar Graph

        categories = list(self.budgets.keys())

        budgets = [self.budgets[cat] for cat in categories]

        expenses = [self.expenses.get(cat, 0) for cat in categories]

        

        plt.figure(figsize=(10, 6))

        plt.bar(categories, budgets, width=0.4, label="Budgets", color="skyblue", align="center")

        plt.bar(categories, expenses, width=0.4, label="Expenses", color="orange", align="edge")

        plt.xticks(rotation=45)

        plt.ylabel("Amount ($)")

        plt.title("Budgets vs Expenses")

        plt.legend(loc="upper right")

        

        plt.text(0.5, -0.3, f"Remaining Monthly Balance: ${remaining_balance}",

                 fontsize=12, color="green", ha="center", transform=plt.gca().transAxes)

        plt.tight_layout()

        plt.show()



# Run Program

if __name__ == "__main__":

    root = tk.Tk()

    app = ExpenseTrackerApp(root)

    root.mainloop()

